#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>


const char THING_ID[] = "95278635-d1bb-4e44-89f8-7db9e6a753ca";

const char SSID[]     = SECRET_SSID;    // Network SSID (name)
const char PASS[]     = SECRET_PASS;    // Network password (use for WPA, or use as key for WEP)

void onButton1Change();
void onButton2Change();
void onButton3Change();
void onButton4Change();
void onButton5Change();
void onStatusChange();
void onPendingMessageChange();

String button1;
String button2;
String button3;
String button4;
String button5;
String status;
int pendingMessage;

void initProperties(){

  ArduinoCloud.setThingId(THING_ID);
  ArduinoCloud.addProperty(button1, READWRITE, ON_CHANGE, onButton1Change);
  ArduinoCloud.addProperty(button2, READWRITE, ON_CHANGE, onButton2Change);
  ArduinoCloud.addProperty(button3, READWRITE, ON_CHANGE, onButton3Change);
  ArduinoCloud.addProperty(button4, READWRITE, ON_CHANGE, onButton4Change);
  ArduinoCloud.addProperty(button5, READWRITE, ON_CHANGE, onButton5Change);
  ArduinoCloud.addProperty(status, READWRITE, ON_CHANGE, onStatusChange);
  ArduinoCloud.addProperty(pendingMessage, READWRITE, ON_CHANGE, onPendingMessageChange);

}

WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);
